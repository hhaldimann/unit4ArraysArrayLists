
public class BoundsError
{
    public static void main(String[] args)
    {
        int[] values = new int[10];
        
        for(int i = 0; i < 10; i++)
        {
            values[i] = i + 1;
        }
    }
}
